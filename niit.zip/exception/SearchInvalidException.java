package org.niit.exception;

    public class SearchInvalidException extends Exception {  //Handling Search Invalid Exception
        public SearchInvalidException(String status) {
            super(status);
        }
    }



