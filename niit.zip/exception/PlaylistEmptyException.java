package org.niit.exception;


    public class PlaylistEmptyException extends Exception{   //Handling Playlist Empty Exception
        public PlaylistEmptyException(String message)
        {
            super(message);


    }
}
