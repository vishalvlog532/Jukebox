package org.niit.enums;

import org.niit.model.Podcast;
import org.niit.model.Song;

public enum PodcastEnum {

     podcastName("PodcastName"),
     celebName("celebName"),
     duration("duration"),
     dateOfUpload("dateOfUpload");



    private  String option;

     PodcastEnum(String option) {
          this.option = option;
     }

     public String getOption() {
          return option;
     }

     public void setOption(String option) {
          this.option = option;
     }
}
