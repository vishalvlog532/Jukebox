package org.niit.enums;

public enum ReleaseType {
    Single("Single"),
    Album("Album");
    private String releaseType;

    ReleaseType(String releaseType) {
        this.releaseType = releaseType;
    }


    public String getReleaseType() {

        return releaseType;
    }

    public void setReleaseType(String releaseType) {

        this.releaseType = releaseType;
    }

}
