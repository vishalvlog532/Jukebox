package org.niit.enums;

public enum PlayEnum {
    Forward("Forward"),
    Reverse("Reverse"),
    Stop("Stop"),
    Pause("Pause"),
    resume("Resume"),
    play("Play");
    private String direction;

    PlayEnum(String direction) {
        this.direction=direction;

    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {

        this.direction = direction;
    }
}
