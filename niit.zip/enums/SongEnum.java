package org.niit.enums;

public enum SongEnum
{
    Artist("Artist"),
    SongName("SongName"),
    AlbumName("AlbumName"),
    PodcastName("PodcastName"),
    PodcastDuration("PodcastDuration"),
    Genre("Genre");
    private String function;

    SongEnum(String function) {

        this.function=function;
    }
    SongEnum(){};

    public String getFunction() {

        return function;
    }

    public void setFunction(String function) {

        this.function = function;
    }
}
