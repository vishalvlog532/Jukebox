package org.niit.model;


import org.niit.enums.ReleaseType;

//attributes of Song
public class Song {
    private String albumName;
    private Artist artist;
    private String songName;
    private String genreType;
    private String releaseDate;
    private String songDuration;
    private ReleaseType releaseType;
    private String fileURl;

    public Song(String albumName, Artist artist, String songName, String genreType, String releaseDate, String songDuration, ReleaseType releaseType, String fileURl) {
        this.albumName = albumName;
        this.artist = artist;
        this.songName = songName;
        this.genreType = genreType;
        this.releaseDate = releaseDate;
        this.songDuration = songDuration;
        this.releaseType = releaseType;
        this.fileURl = fileURl;
    }

    public Song() {

    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public Artist getArtist() {
        return artist;
    }

    public void setArtist(Artist artist) {
        this.artist = artist;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getGenreType() {
        return genreType;
    }

    public void setGenreType(String genreType) {
        this.genreType = genreType;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getSongDuration() {
        return songDuration;
    }

    public void setSongDuration(String songDuration) {
        this.songDuration = songDuration;
    }

    public ReleaseType getReleaseType() {
        return releaseType;
    }

    public void setReleaseType(ReleaseType releaseType) {
        this.releaseType = releaseType;
    }

    public String getFileURl() {
        return fileURl;
    }

    public void setFileURl(String fileURl) {
        this.fileURl = fileURl;
    }

    @Override
    public String toString() {
        return "Song{" +
                "albumName='" + albumName + '\'' +
                ", artist=" + artist +
                ", songName='" + songName + '\'' +
                ", genreType='" + genreType + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", songDuration='" + songDuration + '\'' +
                ", releaseType=" + releaseType +
                ", fileURl='" + fileURl + '\'' +
                '}';
    }
}