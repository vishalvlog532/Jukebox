package org.niit.model;

//attributes of Podcast
public class Podcast {
    private String podcastName;
    private String celebName;
    private String duration;
    private String dateOfUploaded;
    private String fileUrl;

    //Parametrized Constructor


    public Podcast(String podcastName, String celebName, String duration, String dateOfUploaded, String fileUrl) {
        this.podcastName = podcastName;
        this.celebName = celebName;
        this.duration = duration;
        this.dateOfUploaded = dateOfUploaded;
        this.fileUrl = fileUrl;
    }

    public Podcast() {

    }

    public String getPodcastName() {
        return podcastName;
    }

    public void setPodcastName(String podcastName) {
        this.podcastName = podcastName;
    }

    public String getCelebName() {
        return celebName;
    }

    public void setCelebName(String celebName) {
        this.celebName = celebName;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDateOfUploaded() {
        return dateOfUploaded;
    }

    public void setDateOfUploaded(String dateOfUploaded) {
        this.dateOfUploaded = dateOfUploaded;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    @Override
    public String toString() {
        return "Podcast{" +
                "podcastName='" + podcastName + '\'' +
                ", celebName='" + celebName + '\'' +
                ", duration='" + duration + '\'' +
                ", dateOfUploaded='" + dateOfUploaded + '\'' +
                ", fileUrl='" + fileUrl + '\'' +
                '}';
    }
}