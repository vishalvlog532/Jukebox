package org.niit.model;

public class Artist {
    String artistName;
    public  Artist(){

    }

    public  Artist(String artistName) {

        this.artistName = artistName;
    }

    public String getArtistName()
    {
        return artistName;
    }

    public void setArtistName(String artistName) {

        this.artistName = artistName;
    }

    @Override
    public String toString() {
        return "Artist{" +
                "artistName='" + artistName + '\'' +
                '}';
    }
}
