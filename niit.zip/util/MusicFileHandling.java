package org.niit.util;


import org.niit.enums.ReleaseType;
import org.niit.model.Artist;
import org.niit.model.Song;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MusicFileHandling {

    Song song=new Song();
    Artist artist;
    ReleaseType releaseType;
    BufferedReader bufferedReader;

    public List<Song> readFile(String file){
        List<Song> songJukeBoxList=new ArrayList<>();
        try {
            bufferedReader=new BufferedReader(new FileReader(file));
            String line=null;
            bufferedReader.readLine();
            while ((line=bufferedReader.readLine())!=null)
            {

                String[] lineData=line.split(",");
                artist=new Artist(lineData[1]);

                song=new Song(lineData[0],artist,lineData[2],lineData[3],lineData[4],lineData[5],ReleaseType.valueOf(lineData[6]),lineData[7]);
                songJukeBoxList.add(song);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return songJukeBoxList;

    }

}