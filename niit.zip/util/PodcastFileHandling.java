package org.niit.util;


import org.niit.model.Podcast;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PodcastFileHandling {
    Podcast podcast;
    BufferedReader bufferedReader;
    public List<Podcast> readFile(String file){
        List<Podcast> podcastJukeBoxList=new ArrayList<>();
        try {
            bufferedReader=new BufferedReader(new FileReader(file));
            String line=null;
            bufferedReader.readLine();
            while ((line=bufferedReader.readLine())!=null)
            {

                String[] lineData=line.split(",");
                podcast=new Podcast(lineData[0],lineData[1],lineData[2],lineData[3],lineData[4]);
                podcastJukeBoxList.add(podcast);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return podcastJukeBoxList;

    }
}

