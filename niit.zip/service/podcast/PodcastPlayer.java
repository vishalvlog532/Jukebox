package org.niit.service.podcast;

import org.niit.enums.PlayEnum;

import org.niit.model.Podcast;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class PodcastPlayer {
    static public List<Podcast> file=new ArrayList<>();
    public void playSoundList(List<Podcast> file) {
        if (file != null) {
            ListIterator<Podcast> listIterator = file.listIterator();
            String direction = null;
            Scanner scanner = new Scanner(System.in);
            do {
                Podcast filePath = listIterator.next();
                playSound(filePath.getFileUrl());
                System.out.println("Would you like to continue  ? y/n");
                String nextSong = scanner.next();

                if (nextSong.equals("y")) {
                    System.out.println("Give The Direction as per your wish ");
                    direction = scanner.next();
                    if (direction.equals(PlayEnum.Forward.getDirection())){
                        playSound(listIterator.next().getFileUrl());
                    } else if (direction.equals(PlayEnum.Reverse.getDirection())) {
                        playSound(listIterator.previous().getFileUrl());
                    }
                } else {
                    break;
                }
            } while (listIterator.hasNext());
            if (!listIterator.hasNext()) {
                System.out.println("Nothing in the playlist");
                System.out.println("Give The Direction as per your wish");
                String option = scanner.next();
                if (option.equals("y")) {
                    playSoundList(file);
                } else return;
            }
        } else {
            System.out.println("Nothing in the playlist");
        }

    }


    public static void playSound(String filepath) {
        long pauseTime = 0;
        Scanner scanner = new Scanner(System.in);
        for (int i=0;i< file.size();i++)
        {
            filepath=file.get(i).getFileUrl();
        }
        try {
            File audioFile = new File(filepath);
            if (audioFile.exists()) {
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(audioFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                clip.start();
                clip.drain();
                audioInputStream.close();
                String response = "";

                while (!response.equals(PlayEnum.Stop.getDirection())) {
                    System.out.println("Enter your choice");
                    response = scanner.next();
                    if (response.equals(PlayEnum.Pause.getDirection())) {
                        pauseTime = clip.getMicrosecondPosition();
                        clip.stop();
                        System.out.println("Paused at : " + (pauseTime / 1000) + ":mmss");
                    } else if (response.equals(PlayEnum.resume.getDirection())) {
                        clip.setMicrosecondPosition(pauseTime);
                        clip.start();
                    } else if (response.equals(PlayEnum.play.getDirection())){
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                    } else if (response.equals(PlayEnum.Stop.getDirection())) {
                        clip.stop();
                    }
                }

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}





