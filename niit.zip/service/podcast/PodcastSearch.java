package org.niit.service.podcast;

import org.niit.model.Podcast;

import java.util.List;


public class PodcastSearch {
    public Podcast searchByName(List<Podcast> podcastList, String podcastName) {
        Podcast podcast =  podcastList.stream().filter(i -> i.getPodcastName().equalsIgnoreCase(podcastName)).findAny().get();
        return podcast;
    }

    public Podcast searchByCeleb(List<Podcast> podcastList, String celebName) {
        Podcast podcast =  podcastList.stream().filter(i -> i.getCelebName().equalsIgnoreCase(celebName)).findAny().get();
        return podcast;
    }

    public Podcast searchByduration(List<Podcast> podcastList, String duration) {
        Podcast podcast =  podcastList.stream().filter(i -> i.getDuration().equals(duration)).findAny().get();
        return podcast;
    }

    public Podcast searchBydateOfUpload(List<Podcast> podcastList, String dateOfUpload) {
        Podcast podcast =  podcastList.stream().filter(i -> i.getDateOfUploaded().equals(dateOfUpload)).findAny().get();
        return podcast;
    }



}