package org.niit.service.podcast;

import org.niit.model.Podcast;

import java.util.List;
import java.util.stream.Collectors;

public class AddPodcast {
    //Methods to search and add in Playlist According to Podcast attributes
    public List<Podcast> addPodcastByName(List<Podcast> podcastList, String name) {
        List<Podcast> podcastList1 = podcastList.stream().filter(i -> i.getPodcastName().equals(name)).collect(Collectors.toList());
        return podcastList1;

    }
    public static List<Podcast> addPodcastByCelebName(List<Podcast> podcastList, String celebName) {
        List<Podcast> podcastList1 = podcastList.stream().filter(i -> i.getCelebName().equals(celebName)).collect(Collectors.toList());
        return podcastList1;

    }
    public List<Podcast> addPodcastByduration(List<Podcast> podcastList, String duration) {
        List<Podcast> podcastList1 = podcastList.stream().filter(i -> i.getDuration().equals(duration)).collect(Collectors.toList());
        return podcastList1;

    }
    List<Podcast> addPodcastdateOfUpload(List<Podcast> podcastList,String dateOfUpload) {
        List<Podcast> podcastList1 = podcastList.stream().filter(i -> i.getDateOfUploaded().equals(dateOfUpload)).collect(Collectors.toList());
        return podcastList1;

    }
}
