package org.niit.service;

import org.niit.exception.SearchInvalidException;
import org.niit.model.Podcast;
import org.niit.model.Song;


import java.util.List;

public interface JukeBoxImp {
  //Method to search Song to Playlist
  Song searchSong(List<Song> songList, String choices) throws CatalogImp.SearchInvalidException, SearchInvalidException;
  //Method to search Podcast to Playlist
  Podcast searchPodcast(List<Podcast> podcastList, String choices) throws CatalogImp.SearchInvalidException, SearchInvalidException;
}




