package org.niit.service;

import org.niit.enums.PodcastEnum;
import org.niit.enums.SongEnum;

import org.niit.model.Podcast;
import org.niit.model.Song;
import org.niit.service.podcast.AddPodcast;
import org.niit.service.song.AddSong;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PlayListImpl implements IPlayList
{
    static public List<Song> playlist=null;
    static public List<Podcast> playlistPod=null;
    Scanner scanner=new Scanner(System.in);
   AddPodcast addPodcast;
   AddSong addSong ;

   public PlayListImpl(){
       addPodcast = new AddPodcast();
       addSong = new AddSong();
   }

    @Override
    public List<Song> addSongInPlaylist(List<Song> songJukeBoxList, String choice) throws PlayListEmptyException {
        if (songJukeBoxList.isEmpty())
        {
            throw new PlayListEmptyException("Nothing can be added to playlist");
        }
        playlist=new ArrayList();
        if(choice.equals(SongEnum.SongName.toString())) {
            System.out.println("Enter The Song Name");
            String name=scanner.next();
            playlist=addSong.addSongToPlayListBySongName(songJukeBoxList,name);

        }
        else if(choice.equals(SongEnum.AlbumName.toString())) {
            System.out.println("Enter The Album Name");
            String album=scanner.nextLine();
            playlist=addSong.addSongToPlayListByAlbum(songJukeBoxList,album);

        }
        else if(choice.equals(SongEnum.Artist.toString())) {
            System.out.println("Enter The Artist Name");
            String artistName=scanner.next();
            playlist=addSong.addSongToPlayListByArtist(songJukeBoxList,artistName);

        }
        else if(choice.equals(SongEnum.Genre.toString())) {
            System.out.println("Enter The Genre Name");
            String genre=scanner.next();
            playlist=addSong.addSongToPlayListByGenre(songJukeBoxList,genre);

        }
        else {
            throw new PlayListEmptyException("Nothing can be added to playlist");
        }
        return playlist;

    }

    @Override
    public List<Podcast> addPodcastInPlaylist(List<Podcast> podcastBoxList, String choice) throws PlayListEmptyException {
        if (podcastBoxList.isEmpty())
        {
            throw new PlayListEmptyException("Nothing can be added to playlist");
        }
        playlist=new ArrayList();

        if(choice.equals(PodcastEnum.podcastName.toString()))
        {

            System.out.println("Enter The Podcast Name");
            String name = scanner.next();
            playlistPod = addPodcast.addPodcastByName(podcastBoxList, name);
        }

        else if(choice.equals(PodcastEnum.celebName.toString())){

            System.out.println("Enter The Podcast Celeb Name");
            String celebname=scanner.nextLine();
            playlistPod=addPodcast.addPodcastByCelebName(podcastBoxList,celebname);
        }
        else if(choice.equals(PodcastEnum.duration.toString())){

            System.out.println("Enter The Podcast Duration");
            String duration=scanner.next();
            playlistPod=addPodcast.addPodcastByduration(podcastBoxList,duration);
        }

        else {
            System.out.println("OOPS YOU HAVE ENTERED THE WRONG THING");
        }
        return playlistPod;

    }



    //Sorting the song Playlist

    public void sortSong(List<Song> playlist){
        playlist.stream().sorted().forEach(System.out::println);
    }

    //Sorting the Podcast Playlist

    public void sortPodcast(List<Podcast> playlistPod){
        playlistPod.stream().sorted().forEach(System.out::println);
    }

    //This is the Exception class
    public class PlayListEmptyException extends Exception{
        public PlayListEmptyException(String message)
        {
            super(message);
        }

    }


}