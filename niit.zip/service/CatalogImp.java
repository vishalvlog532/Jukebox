package org.niit.service;

import org.niit.enums.PodcastEnum;
import org.niit.enums.SongEnum;

import org.niit.model.Podcast;
import org.niit.model.Song;
import org.niit.service.podcast.PodcastSearch;
import org.niit.service.song.SongSearch;

import java.util.List;
import java.util.Scanner;

public class CatalogImp implements JukeBoxImp {
    SongSearch songSearch;
    Scanner scanner;
    PodcastSearch podcastSearch;
    Song song;
    Podcast podcast;
    List<Song> songList;
    List<Podcast> podcastList;

    public CatalogImp() {
        podcastSearch = new PodcastSearch();
        songSearch = new SongSearch();
        scanner = new Scanner(System.in);
    }

    @Override
    public Song searchSong(List<Song> songJukeBoxList, String choice) throws SearchInvalidException {
        if (choice.equals(SongEnum.SongName.toString())) {
            System.out.println("Enter The Song Name");
            String songName = scanner.nextLine();
            song = songSearch.searchBySong(songJukeBoxList, songName);

        } else if (choice.equals(SongEnum.Artist.toString())) {
            System.out.println("Enter The Artist Name");
            String artist = scanner.nextLine();
            song = songSearch.searchByArtist(songJukeBoxList, artist);


        } else if (choice.equals(SongEnum.AlbumName.toString())) {
            System.out.println("Enter The Album Name");
            String album = scanner.nextLine();
            song = songSearch.searchByAlbum(songJukeBoxList, album);

        } else if (choice.equals(SongEnum.Genre.toString())) {
            System.out.println("Enter The Genre Of the Song ");
            String genre = scanner.nextLine();
            song = songSearch.searchByGenre(songJukeBoxList, genre);

        } else {
            throw new SearchInvalidException("NO DATA FOUND INSIDE THE PLAYLIST ! PLEASE DO IT AGAIN");
        }
        return song;
    }

    @Override
    public Podcast searchPodcast(List<Podcast> podcastJukeBoxList, String podcastChoice) throws SearchInvalidException {
        if (podcastChoice.equals(PodcastEnum.podcastName.toString())) {
            System.out.println("Enter The Podcast Name");
            String Name = scanner.nextLine();
            podcast = podcastSearch.searchByName(podcastList, Name);


        } else if (podcastChoice.equals(PodcastEnum.celebName.toString())) {
            System.out.println("Enter The Celeb Name");
            String celebName = scanner.next();
            podcast = podcastSearch.searchByCeleb(podcastJukeBoxList, celebName);


        } else if (podcastChoice.equals(PodcastEnum.dateOfUpload.toString())) {
            System.out.println("Enter The Date");
            String date = scanner.next();
            podcast = podcastSearch.searchBydateOfUpload(podcastJukeBoxList, date);


        } else {
            throw new SearchInvalidException("NO DATA FOUND INSIDE THE PLAYLIST ! PLEASE DO IT AGAIN");
        }
        return podcast;

    }

    public class SearchInvalidException extends Exception {
        public SearchInvalidException(String status) {
            super(status);
        }
    }
}






