
package org.niit.service;


import org.niit.model.Podcast;
import org.niit.model.Song;
import org.niit.service.podcast.PodcastPlayer;
import org.niit.service.song.Songplayer;
import org.niit.util.MusicFileHandling;
import org.niit.util.PodcastFileHandling;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

    public class jukeImpl {
        public static void main(String[] args) throws PlayListImpl.PlayListEmptyException {
            PlayListImpl playList = new PlayListImpl();
            CatalogImp catalogImp = new CatalogImp();
            MusicFileHandling musicFileHandling = new MusicFileHandling();
            PodcastFileHandling podcastFileHandling = new PodcastFileHandling();
            Songplayer songplayer = new Songplayer();
            PodcastPlayer podcastPlayer = new PodcastPlayer();
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n----------------WELCOME IN MY MEDIA PLAYER 'JUKE-BOX'-----------\n \t Press Any key to continue");
            scanner.next();
            System.out.println("--------------Choose Any Appropriate option----------- \n 1.Enter MUSIC for Song \n 2.Enter CLIP for Podcast \n 3.Enter Both for Song and Podcast"); //Choose Between the two
            String audioType = scanner.next();
            switch (audioType) {
                case "MUSIC":
                    List<Song> songData = musicFileHandling.readFile("src/main/resources/Song.csv");
                    Stream stream2 = songData.stream();
                    System.out.println("Album Name\t\t\t\t Artist Name\t\t\t\t Song Name\t\t\t\t Genre\t\t\t\t Release Date\t\t\t Song Duration\t\t\t\t" +
                            "Release Type\t\t\t\t\t file");
                    stream2.forEach(i -> System.out.println(i + "\t"));
                    System.out.println("\nWhich Mode You Want to Play First\n\n\n1.Press 1 for Song Mode\n\n2.Press 2 for Playlist Mode");
                    int mode = scanner.nextInt();
                    if (mode == 1) {
                        System.out.println("1.Enter AlbumName to search Album \n\n\n2.Enter SongName to search Song \n\n\n 3.Enter Artist to search Artist \n\n\n 4.Enter Genre to search Genre");
                        String searchChoice = scanner.next();
                        try {
                            Song searchedSong = catalogImp.searchSong(songData, searchChoice);
                            System.out.println("Album Name\t\t\t\t\t Artist Name\t\t\t\t\t Song Name\t\t\t\t\t\t Genre\t\t\t\t\t\t Release Date\t\t\t\t\t\t Song Duration\t\t\t\t\t\t " +
                                    "Release Type\t\t\t\t\t\t file");
                            System.out.println(searchedSong);
                        } catch (CatalogImp.SearchInvalidException searchInvalidException) {
                            searchInvalidException.printStackTrace();
                        }
                        break;

                    } else if (mode == 2) {
                        System.out.println("1.Enter AlbumName to add Album in Playlist\n\n\n2.Enter SongName to add Song in Playlist\n\n\n3.Enter Arist Name to add Artist\n\n\n4.Enter Genre to add Genre");
                        String choice = scanner.next();
                        List playlist1 = playList.addSongInPlaylist(songData, choice);
                        Stream stream = playlist1.stream();
                        System.out.println("Album Name\t Artist Name\t Song Name\t Genre\t Release Date\t Song Duration\t " +
                                "Release Type\t file");
                        stream.forEach(s -> System.out.println(s + "\t"));
                        songplayer.playSoundList(playlist1);
                        break;
                    } else {
                        break;
                    }

                case "CLIP":
                    List<Podcast> podcastData = podcastFileHandling.readFile("src/main/resources/Podcast.csv");
                    Stream stream1 = podcastData.stream();
                    System.out.println("Podcast Name\t\t\t\t Celeb Name\t\t\t\t Duration\t\t\t\t Date of Upload\t\t\t file Url ");
                    stream1.forEach(d -> System.out.println(d + "\t\t\t\t\t\t"));
                    System.out.println("Which Mode You Want to Play First\n\n\n1.Press 1 for Song Mode\n\n\n2.Press 2 for Playlist Mode");
                    int podcastMode = scanner.nextInt();
                    if (podcastMode == 1) {
                        System.out.println("Enter PodcastName to search Podcast using Podcast Name" +
                                "\n\n\nEnter PodcastCelebName to search Podcast using Celeb Name" +
                                "\n\n\nEnter DateOfUpload search Podcast using Date of Upload");
                        String searchChoice = scanner.next();
                        try {
                            Podcast searchedPodcast = catalogImp.searchPodcast(podcastData, searchChoice);
                            System.out.println("Podcast Name\t\t\t\t Celeb Name\t\t\t\t\t Duration\t\t\t\t\t Date of Upload\t\t\t\t\t file Url ");
                            System.out.println(searchedPodcast);
                        } catch (CatalogImp.SearchInvalidException searchInvalidException) {
                            searchInvalidException.printStackTrace();
                        }
                        break;

                    } else if (podcastMode == 2) {
                        System.out.println("1.Enter PodcastName to add Podcast in Playlist\n\n\n2.Enter CelebName to add Podcast in Playlist\n\n\n3.Enter DateOfUpload to add in PlayList");
                        String choice = scanner.next();
                        List playlistPod = playList.addPodcastInPlaylist(podcastData, choice);
                        Stream stream = playlistPod.stream();
                        System.out.println("Podcast Name\t Celeb Name\t Duration\t Date of Upload\t file Url ");
                        stream.forEach(s -> System.out.println(s + "\t"));
                        podcastPlayer.playSoundList(playlistPod);
                        break;
                    } else {
                        break;
                    }
                case "Both":
                    List<Song> OnlySongData = musicFileHandling.readFile("src/main/resources/Song.csv");
                    List<Podcast> OnlyPodcastData = podcastFileHandling.readFile("src/main/resources/Podcast.csv");
                    Stream songStream = OnlySongData.stream();
                    songStream.forEach(c -> System.out.println(c + "\t"));
                    Stream podcastStream = OnlyPodcastData.stream();
                    podcastStream.forEach(c -> System.out.println(c + "\t"));
                    System.out.println("What Whould You Like to Play ?");
                    String options = scanner.next();
                    if (options.equals("MUSIC")) {
                        songplayer.playSoundList(OnlySongData);
                    } else if (options.equals("CLIP")) {
                        podcastPlayer.playSoundList(OnlyPodcastData);
                    } else {
                        System.out.println("GREAT YOU HAVE CHOSEN A RIGHT VALUE");
                    }
                default:
                    System.out.println("SORRY! YOU HAVE ENTERED A WRONG VAULE");
            }
        }
    }




