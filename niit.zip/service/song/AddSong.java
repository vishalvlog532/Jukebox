package org.niit.service.song;


import org.niit.model.Song;

import java.util.List;
import java.util.stream.Collectors;

public class AddSong {
    //Methods to search and add in Playlist According to Song attributes
    public List<Song> addSongToPlayListByArtist(List<Song> songJukeBoxList, String artist)
    {
        List<Song> songList=songJukeBoxList.stream().filter(c-> c.getArtist().getArtistName().equalsIgnoreCase(artist)).collect(Collectors.toList());
        return songList;
    }

    public static List<Song> addSongToPlayListByAlbum(List<Song> songJukeBoxList, String album)
    {
        List<Song> songList=songJukeBoxList.stream().filter(c-> c.getAlbumName().equalsIgnoreCase(album)).collect(Collectors.toList());
        return songList;
    }

    public static List<Song> addSongToPlayListBySongName(List<Song> songJukeBoxList, String song)
    {
        List<Song> songList=songJukeBoxList.stream().filter(c-> c.getSongName().equalsIgnoreCase(song)).collect(Collectors.toList());
        return songList;
    }
    public List<Song> addSongToPlayListByGenre(List<Song> songJukeBoxList, String genre)
    {
        List<Song> songList=songJukeBoxList.stream().filter(c-> c.getGenreType().equalsIgnoreCase(genre)).collect(Collectors.toList());
        return songList;
    }

}