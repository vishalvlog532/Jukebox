package org.niit.service.song;


import org.niit.model.Song;

import java.util.List;


public class SongSearch {
    Song song;
    public Song searchBySong(List<Song> songJukeBoxList, String songName)
    {
        Song song1=songJukeBoxList.stream().filter(c->c.getSongName().equals(songName)).findAny().get();
        return song1;
    }
    public Song searchByArtist(List<Song> songJukeBoxList, String artistName)
    {
        Song song1=songJukeBoxList.stream().filter(c->c.getArtist().equals(artistName)).findAny().get();
        return song1;
    }
    public Song searchByAlbum(List<Song> songJukeBoxList, String albumName)
    {
        Song song1=songJukeBoxList.stream().filter(c->c.getAlbumName().equals(albumName)).findAny().get();
        return song1;
    }

    public Song searchByGenre(List<Song> songJukeBoxList, String genreName)
    {
        Song song1=songJukeBoxList.stream().filter(c->c.getGenreType().equals(genreName)).findAny().get();
        return song1;
    }


}
