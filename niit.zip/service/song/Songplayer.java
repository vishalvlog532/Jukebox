package org.niit.service.song;

import org.niit.enums.PlayEnum;
import org.niit.model.Song;

import javax.sound.sampled.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;


public class Songplayer {
    static public List<Song> file=new ArrayList<>();
    public void playSoundList(List<Song> file) {
        if (file != null) {
            ListIterator<Song> listIterator = file.listIterator();
            String direction = null;
            Scanner scanner = new Scanner(System.in);
            do {
                 Song filePath = listIterator.next();
                playSound(filePath.getFileURl());
                System.out.println("Would you like to continue  ? y/n");
                String nextSong = scanner.nextLine();

                if (nextSong.equals("y")) {
                    System.out.println("Give The Direction as per your wish ");
                    direction = scanner.next();
                    try {
                        if (direction.equals(PlayEnum.Forward.getDirection())) {
                            playSound(listIterator.next().getFileURl());
                        } else if (direction.equals(PlayEnum.Reverse.getDirection())) {
                            playSound(listIterator.previous().getFileURl());
                        }
                    } catch (Exception e) {
                        System.out.println("Nothing in the playlist");
                    }

                } else {
                    break;
                }
            } while (listIterator.hasNext());
            if (!listIterator.hasNext()) {
                System.out.println("Nothing in the playlist");
                System.out.println("Give The Direction as per your wish");
                String option = scanner.next();
                if (option.equals("y")) {
                    playSoundList(file);
                } else return;
            }
        } else {
            System.out.println("Nothing in the playlist");
        }

    }

    public static void playSound(String filepath) {
        long pauseTime = 0;
        Scanner scanner = new Scanner(System.in);
        for (int i=0;i< file.size();i++)
        {
            filepath=file.get(i).getFileURl();
        }
        try {
            File audioFile = new File(filepath);
            if (audioFile.exists()) {
                AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(audioFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioInputStream);
                clip.start();
                clip.drain();
                audioInputStream.close();
                String response = "";

                while (!response.equals(PlayEnum.Stop.getDirection())) {
                    System.out.println("Choose the option as per your wish \n\n 1.Enter Stop for stopping the music \n\n  2.Enter Pause  for Pausing the music  \n\n 3.Enter Resume for Resumimg the music  \n\n  4.Enter Play to Restart the music");
                    response = scanner.next();
                    if (response.equals(PlayEnum.Pause.getDirection()))
                    {
                        pauseTime = clip.getMicrosecondPosition();
                        clip.stop();
                        System.out.println("Paused at : " + (pauseTime / 1000) + ":mmss");
                    }
                    else if (response.equals(PlayEnum.resume.getDirection()))
                    {
                        clip.setMicrosecondPosition(pauseTime);
                        clip.start();
                    } else if (response.equals(PlayEnum.play.getDirection())) {
                        clip.loop(Clip.LOOP_CONTINUOUSLY);
                    } else if (response.equals(PlayEnum.Stop.getDirection())) {
                        clip.stop();
                    }
                }

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


}





