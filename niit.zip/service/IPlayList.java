package org.niit.service;

import org.niit.model.Podcast;
import org.niit.model.Song;



import java.util.List;

public interface IPlayList {
    //Method to add Song to Playlist
    List<Song> addSongInPlaylist(List<Song> songJukeBoxList, String choice) throws PlayListImpl.PlayListEmptyException;
    //Method to add Podcast to PlayList
    List<Podcast> addPodcastInPlaylist(List<Podcast> podcastBoxList, String choice) throws PlayListImpl.PlayListEmptyException;


}
